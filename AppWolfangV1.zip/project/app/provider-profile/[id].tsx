import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ArrowLeft, Star, MapPin, Phone, MessageCircle, Share2, Heart, Clock, CircleCheck as CheckCircle } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useState } from 'react';

const mockProvider = {
  id: 1,
  name: 'TechFix Pro',
  category: 'Tecnología',
  rating: 4.8,
  reviews: 124,
  image: 'https://images.pexels.com/photos/5380589/pexels-photo-5380589.jpeg?auto=compress&cs=tinysrgb&w=400',
  coverImage: 'https://images.pexels.com/photos/325153/pexels-photo-325153.jpeg?auto=compress&cs=tinysrgb&w=800',
  location: 'Ciudad de México',
  distance: '0.5 km',
  phone: '+52 55 1234 5678',
  description: 'Especialistas en reparación de equipos electrónicos con más de 10 años de experiencia. Ofrecemos servicio a domicilio y garantía en todos nuestros trabajos.',
  services: [
    { id: 1, name: 'Reparación de computadoras', price: 'Desde $500' },
    { id: 2, name: 'Instalación de software', price: 'Desde $200' },
    { id: 3, name: 'Mantenimiento preventivo', price: 'Desde $300' },
    { id: 4, name: 'Recuperación de datos', price: 'Desde $800' },
  ],
  workingHours: {
    monday: '9:00 AM - 6:00 PM',
    tuesday: '9:00 AM - 6:00 PM',
    wednesday: '9:00 AM - 6:00 PM',
    thursday: '9:00 AM - 6:00 PM',
    friday: '9:00 AM - 6:00 PM',
    saturday: '10:00 AM - 4:00 PM',
    sunday: 'Cerrado',
  },
  gallery: [
    'https://images.pexels.com/photos/325153/pexels-photo-325153.jpeg?auto=compress&cs=tinysrgb&w=300',
    'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=300',
    'https://images.pexels.com/photos/139387/pexels-photo-139387.jpeg?auto=compress&cs=tinysrgb&w=300',
  ],
  reviews: [
    {
      id: 1,
      userName: 'María González',
      rating: 5,
      comment: 'Excelente servicio, repararon mi laptop muy rápido y quedó como nueva.',
      date: '2024-01-15',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100',
    },
    {
      id: 2,
      userName: 'Carlos Ruiz',
      rating: 5,
      comment: 'Muy profesionales, llegaron puntual y resolvieron el problema de mi PC.',
      date: '2024-01-10',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100',
    },
    {
      id: 3,
      userName: 'Ana López',
      rating: 4,
      comment: 'Buen servicio, aunque tardaron un poco más de lo esperado.',
      date: '2024-01-08',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100',
    },
  ],
  verified: true,
  responseTime: '2 horas promedio',
};

export default function ProviderProfileScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [isFavorite, setIsFavorite] = useState(false);

  const handleContact = (method: 'call' | 'message' | 'whatsapp') => {
    switch (method) {
      case 'call':
        Alert.alert('Llamar', `¿Deseas llamar a ${mockProvider.name}?`, [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Llamar', onPress: () => console.log('Calling...') },
        ]);
        break;
      case 'message':
        router.push(`/chat/${mockProvider.id}`);
        break;
      case 'whatsapp':
        Alert.alert('WhatsApp', `Abrir chat de WhatsApp con ${mockProvider.name}?`);
        break;
    }
  };

  const handleShare = () => {
    Alert.alert('Compartir', 'Compartir perfil del proveedor');
  };

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
    Alert.alert(
      isFavorite ? 'Eliminado de favoritos' : 'Agregado a favoritos',
      isFavorite ? 
        'El proveedor ha sido eliminado de tus favoritos' : 
        'El proveedor ha sido agregado a tus favoritos'
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Image source={{ uri: mockProvider.coverImage }} style={styles.coverImage} />
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.7)']}
          style={styles.coverOverlay}
        />
        <View style={styles.headerControls}>
          <TouchableOpacity 
            style={styles.headerButton}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color="#FFFFFF" />
          </TouchableOpacity>
          <View style={styles.headerActions}>
            <TouchableOpacity 
              style={styles.headerButton}
              onPress={handleShare}
            >
              <Share2 size={24} color="#FFFFFF" />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.headerButton}
              onPress={toggleFavorite}
            >
              <Heart 
                size={24} 
                color={isFavorite ? "#EF4444" : "#FFFFFF"} 
                fill={isFavorite ? "#EF4444" : "none"}
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Provider Info */}
        <View style={styles.providerInfo}>
          <View style={styles.providerHeader}>
            <Image source={{ uri: mockProvider.image }} style={styles.providerAvatar} />
            <View style={styles.providerDetails}>
              <View style={styles.providerNameContainer}>
                <Text style={styles.providerName}>{mockProvider.name}</Text>
                {mockProvider.verified && (
                  <CheckCircle size={20} color="#10B981" />
                )}
              </View>
              <Text style={styles.providerCategory}>{mockProvider.category}</Text>
              <View style={styles.providerMeta}>
                <View style={styles.rating}>
                  <Star size={16} color="#F59E0B" fill="#F59E0B" />
                  <Text style={styles.ratingText}>{mockProvider.rating}</Text>
                  <Text style={styles.reviewsCount}>({mockProvider.reviews} reseñas)</Text>
                </View>
                <View style={styles.location}>
                  <MapPin size={14} color="#6B7280" />
                  <Text style={styles.locationText}>{mockProvider.distance}</Text>
                </View>
              </View>
            </View>
          </View>

          <Text style={styles.description}>{mockProvider.description}</Text>

          {/* Response Time */}
          <View style={styles.responseTime}>
            <Clock size={16} color="#3B82F6" />
            <Text style={styles.responseTimeText}>Tiempo de respuesta: {mockProvider.responseTime}</Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity 
            style={[styles.actionButton, styles.primaryAction]}
            onPress={() => handleContact('message')}
          >
            <MessageCircle size={20} color="#FFFFFF" />
            <Text style={styles.primaryActionText}>Mensaje</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionButton, styles.secondaryAction]}
            onPress={() => handleContact('call')}
          >
            <Phone size={20} color="#3B82F6" />
            <Text style={styles.secondaryActionText}>Llamar</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionButton, styles.secondaryAction]}
            onPress={() => handleContact('whatsapp')}
          >
            <Text style={styles.whatsappIcon}>💬</Text>
            <Text style={styles.secondaryActionText}>WhatsApp</Text>
          </TouchableOpacity>
        </View>

        {/* Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Servicios</Text>
          {mockProvider.services.map((service) => (
            <View key={service.id} style={styles.serviceItem}>
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.servicePrice}>{service.price}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Working Hours */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Horarios de Atención</Text>
          <View style={styles.workingHours}>
            {Object.entries(mockProvider.workingHours).map(([day, hours]) => (
              <View key={day} style={styles.hourItem}>
                <Text style={styles.dayText}>{day.charAt(0).toUpperCase() + day.slice(1)}</Text>
                <Text style={[styles.hourText, hours === 'Cerrado' && styles.closedText]}>
                  {hours}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Gallery */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Galería</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {mockProvider.gallery.map((image, index) => (
              <TouchableOpacity key={index} style={styles.galleryItem}>
                <Image source={{ uri: image }} style={styles.galleryImage} />
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Reviews */}
        <View style={styles.section}>
          <View style={styles.reviewsHeader}>
            <Text style={styles.sectionTitle}>Reseñas</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>Ver todas</Text>
            </TouchableOpacity>
          </View>
          {mockProvider.reviews.slice(0, 3).map((review) => (
            <View key={review.id} style={styles.reviewItem}>
              <View style={styles.reviewHeader}>
                <Image source={{ uri: review.avatar }} style={styles.reviewAvatar} />
                <View style={styles.reviewInfo}>
                  <Text style={styles.reviewerName}>{review.userName}</Text>
                  <View style={styles.reviewRating}>
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} size={12} color="#F59E0B" fill="#F59E0B" />
                    ))}
                  </View>
                </View>
                <Text style={styles.reviewDate}>{review.date}</Text>
              </View>
              <Text style={styles.reviewComment}>{review.comment}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    height: 200,
    position: 'relative',
  },
  coverImage: {
    width: '100%',
    height: '100%',
  },
  coverOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '50%',
  },
  headerControls: {
    position: 'absolute',
    top: 20,
    left: 20,
    right: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  content: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    marginTop: -24,
  },
  providerInfo: {
    padding: 20,
  },
  providerHeader: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  providerAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  providerDetails: {
    flex: 1,
  },
  providerNameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  providerName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
  },
  providerCategory: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 8,
  },
  providerMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
  },
  reviewsCount: {
    fontSize: 14,
    color: '#6B7280',
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationText: {
    fontSize: 14,
    color: '#6B7280',
  },
  description: {
    fontSize: 16,
    color: '#374151',
    lineHeight: 24,
    marginBottom: 12,
  },
  responseTime: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#EFF6FF',
    padding: 12,
    borderRadius: 8,
  },
  responseTimeText: {
    fontSize: 14,
    color: '#3B82F6',
    fontWeight: '600',
  },
  actionButtons: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingBottom: 20,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
  },
  primaryAction: {
    backgroundColor: '#3B82F6',
  },
  secondaryAction: {
    backgroundColor: '#F3F4F6',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  primaryActionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  secondaryActionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#3B82F6',
  },
  whatsappIcon: {
    fontSize: 20,
  },
  section: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  serviceItem: {
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  serviceInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  servicePrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#3B82F6',
  },
  workingHours: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
  },
  hourItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  dayText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  hourText: {
    fontSize: 16,
    color: '#6B7280',
  },
  closedText: {
    color: '#EF4444',
    fontWeight: '600',
  },
  galleryItem: {
    marginRight: 12,
  },
  galleryImage: {
    width: 120,
    height: 90,
    borderRadius: 8,
  },
  reviewsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  viewAllText: {
    fontSize: 16,
    color: '#3B82F6',
    fontWeight: '600',
  },
  reviewItem: {
    marginBottom: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  reviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  reviewAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  reviewInfo: {
    flex: 1,
  },
  reviewerName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  reviewRating: {
    flexDirection: 'row',
    gap: 2,
  },
  reviewDate: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  reviewComment: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
  },
});
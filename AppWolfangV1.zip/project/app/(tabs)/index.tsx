import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useContext } from 'react';
import { Search, MapPin, Bell, Star } from 'lucide-react-native';
import { AuthContext } from '@/contexts/AuthContext';
import { LinearGradient } from 'expo-linear-gradient';

const categories = [
  { id: 1, name: 'Reparaciones', icon: '🔧', color: '#EF4444' },
  { id: 2, name: 'Hogar y Jardinería', icon: '🏠', color: '#10B981' },
  { id: 3, name: 'Transporte', icon: '🚗', color: '#3B82F6' },
  { id: 4, name: 'Salud y Bienestar', icon: '💊', color: '#8B5CF6' },
  { id: 5, name: 'Educación', icon: '📚', color: '#F59E0B' },
  { id: 6, name: 'Bodas y Eventos', icon: '💒', color: '#EC4899' },
  { id: 7, name: 'Fotografía', icon: '📸', color: '#06B6D4' },
  { id: 8, name: 'Belleza', icon: '💄', color: '#F97316' },
  { id: 9, name: 'Mascotas', icon: '🐕', color: '#84CC16' },
  { id: 10, name: 'Delivery', icon: '🛒', color: '#6366F1' },
  { id: 11, name: 'Tecnología', icon: '💻', color: '#059669' },
  { id: 12, name: 'Profesionales', icon: '⚖️', color: '#DC2626' },
];

const featuredProviders = [
  {
    id: 1,
    name: 'TechFix Pro',
    category: 'Tecnología',
    rating: 4.8,
    image: 'https://images.pexels.com/photos/5380589/pexels-photo-5380589.jpeg?auto=compress&cs=tinysrgb&w=400',
    location: '0.5 km',
  },
  {
    id: 2,
    name: 'Jardines Elite',
    category: 'Jardinería',
    rating: 4.9,
    image: 'https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=400',
    location: '1.2 km',
  },
];

export default function HomeScreen() {
  const { user } = useContext(AuthContext);
  const isProvider = user?.userType === 'provider';

  if (isProvider) {
    return <ProviderHome />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <View>
              <Text style={styles.greeting}>¡Hola, {user?.name || 'Usuario'}!</Text>
              <View style={styles.locationContainer}>
                <MapPin size={14} color="#6B7280" />
                <Text style={styles.location}>Ciudad de México</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.notificationButton}>
              <Bell size={24} color="#374151" />
              <View style={styles.notificationBadge} />
            </TouchableOpacity>
          </View>
          
          {/* Search Bar */}
          <View style={styles.searchContainer}>
            <Search size={20} color="#9CA3AF" />
            <TextInput
              style={styles.searchInput}
              placeholder="¿Qué servicio necesitas?"
              placeholderTextColor="#9CA3AF"
            />
          </View>
        </View>

        {/* Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Categorías</Text>
          <View style={styles.categoriesGrid}>
            {categories.map((category) => (
              <TouchableOpacity key={category.id} style={styles.categoryCard}>
                <View style={[styles.categoryIcon, { backgroundColor: category.color + '20' }]}>
                  <Text style={styles.categoryEmoji}>{category.icon}</Text>
                </View>
                <Text style={styles.categoryName}>{category.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Featured Providers */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Proveedores Destacados</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {featuredProviders.map((provider) => (
              <TouchableOpacity key={provider.id} style={styles.providerCard}>
                <Image source={{ uri: provider.image }} style={styles.providerImage} />
                <LinearGradient
                  colors={['transparent', 'rgba(0,0,0,0.8)']}
                  style={styles.providerOverlay}
                />
                <View style={styles.providerInfo}>
                  <Text style={styles.providerName}>{provider.name}</Text>
                  <Text style={styles.providerCategory}>{provider.category}</Text>
                  <View style={styles.providerMeta}>
                    <View style={styles.rating}>
                      <Star size={12} color="#F59E0B" fill="#F59E0B" />
                      <Text style={styles.ratingText}>{provider.rating}</Text>
                    </View>
                    <Text style={styles.distance}>{provider.location}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Acceso Rápido</Text>
          <View style={styles.quickActions}>
            <TouchableOpacity style={styles.quickAction}>
              <View style={styles.quickActionIcon}>
                <MapPin size={24} color="#3B82F6" />
              </View>
              <Text style={styles.quickActionText}>Cerca de ti</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickAction}>
              <View style={styles.quickActionIcon}>
                <Star size={24} color="#F59E0B" />
              </View>
              <Text style={styles.quickActionText}>Mejor valorados</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function ProviderHome() {
  const { user } = useContext(AuthContext);
  
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Provider Header */}
        <View style={styles.providerHeader}>
          <LinearGradient
            colors={['#3B82F6', '#1D4ED8']}
            style={styles.providerGradient}
          />
          <View style={styles.providerHeaderContent}>
            <Text style={styles.providerGreeting}>¡Bienvenido de vuelta!</Text>
            <Text style={styles.providerName}>{user?.businessName || 'Mi Negocio'}</Text>
            <View style={styles.subscriptionBadge}>
              <Text style={styles.subscriptionText}>Plan Premium</Text>
            </View>
          </View>
        </View>

        {/* Provider Dashboard */}
        <View style={styles.dashboard}>
          <View style={styles.dashboardGrid}>
            <TouchableOpacity style={styles.dashboardCard}>
              <View style={styles.dashboardIcon}>
                <User size={24} color="#3B82F6" />
              </View>
              <Text style={styles.dashboardTitle}>Editar Perfil</Text>
              <Text style={styles.dashboardSubtitle}>Actualiza tu información</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.dashboardCard}>
              <View style={styles.dashboardIcon}>
                <Star size={24} color="#F59E0B" />
              </View>
              <Text style={styles.dashboardTitle}>Suscripción</Text>
              <Text style={styles.dashboardSubtitle}>Gestiona tu plan</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.dashboardCard}>
              <View style={styles.dashboardIcon}>
                <MessageCircle size={24} color="#10B981" />
              </View>
              <Text style={styles.dashboardTitle}>Mensajes</Text>
              <Text style={styles.dashboardSubtitle}>3 nuevos mensajes</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.dashboardCard}>
              <View style={styles.dashboardIcon}>
                <Bell size={24} color="#F97316" />
              </View>
              <Text style={styles.dashboardTitle}>Estadísticas</Text>
              <Text style={styles.dashboardSubtitle}>Ver rendimiento</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Recent Activity */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Actividad Reciente</Text>
          <View style={styles.activityList}>
            <View style={styles.activityItem}>
              <View style={styles.activityIndicator} />
              <View>
                <Text style={styles.activityText}>Nueva reseña de 5 estrellas</Text>
                <Text style={styles.activityTime}>Hace 2 horas</Text>
              </View>
            </View>
            <View style={styles.activityItem}>
              <View style={styles.activityIndicator} />
              <View>
                <Text style={styles.activityText}>Nuevo contacto de cliente</Text>
                <Text style={styles.activityTime}>Hace 4 horas</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  location: {
    fontSize: 14,
    color: '#6B7280',
  },
  notificationButton: {
    position: 'relative',
    padding: 8,
  },
  notificationBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  categoryCard: {
    width: '30%',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  categoryIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryEmoji: {
    fontSize: 20,
  },
  categoryName: {
    fontSize: 12,
    fontWeight: '600',
    color: '#374151',
    textAlign: 'center',
  },
  providerCard: {
    width: 200,
    height: 120,
    marginRight: 16,
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
  },
  providerImage: {
    width: '100%',
    height: '100%',
  },
  providerOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
  },
  providerInfo: {
    position: 'absolute',
    bottom: 12,
    left: 12,
    right: 12,
  },
  providerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  providerCategory: {
    fontSize: 12,
    color: '#D1D5DB',
    marginBottom: 4,
  },
  providerMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  ratingText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  distance: {
    fontSize: 12,
    color: '#D1D5DB',
  },
  quickActions: {
    flexDirection: 'row',
    gap: 16,
  },
  quickAction: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  quickActionText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    textAlign: 'center',
  },
  // Provider specific styles
  providerHeader: {
    height: 160,
    position: 'relative',
  },
  providerGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  providerHeaderContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  providerGreeting: {
    fontSize: 16,
    color: '#FFFFFF',
    opacity: 0.9,
    marginBottom: 4,
  },
  providerName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  subscriptionBadge: {
    backgroundColor: '#10B981',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 16,
  },
  subscriptionText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  dashboard: {
    padding: 20,
  },
  dashboardGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  dashboardCard: {
    width: '47%',
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  dashboardIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  dashboardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 4,
  },
  dashboardSubtitle: {
    fontSize: 12,
    color: '#6B7280',
  },
  activityList: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 12,
  },
  activityIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#3B82F6',
  },
  activityText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 12,
    color: '#6B7280',
  },
});
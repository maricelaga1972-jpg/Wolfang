import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Star, MapPin, Heart } from 'lucide-react-native';

const favoriteProviders = [
  {
    id: 1,
    name: 'TechFix Pro',
    category: 'Tecnología',
    rating: 4.8,
    reviews: 124,
    image: 'https://images.pexels.com/photos/5380589/pexels-photo-5380589.jpeg?auto=compress&cs=tinysrgb&w=300',
    distance: '0.5 km',
    price: 'Desde $500',
    lastContacted: '2 días atrás',
  },
  {
    id: 2,
    name: 'Jardines Elite',
    category: 'Jardinería',
    rating: 4.9,
    reviews: 89,
    image: 'https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=300',
    distance: '1.2 km',
    price: 'Desde $800',
    lastContacted: '1 semana atrás',
  },
  {
    id: 3,
    name: 'Beauty Studio',
    category: 'Belleza',
    rating: 4.7,
    reviews: 156,
    image: 'https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg?auto=compress&cs=tinysrgb&w=300',
    distance: '2.1 km',
    price: 'Desde $300',
    lastContacted: '3 días atrás',
  },
];

export default function FavoritesScreen() {
  const renderFavoriteCard = ({ item }: { item: typeof favoriteProviders[0] }) => (
    <TouchableOpacity style={styles.favoriteCard}>
      <Image source={{ uri: item.image }} style={styles.favoriteImage} />
      <View style={styles.favoriteContent}>
        <View style={styles.favoriteHeader}>
          <Text style={styles.favoriteName}>{item.name}</Text>
          <TouchableOpacity style={styles.heartButton}>
            <Heart size={20} color="#EF4444" fill="#EF4444" />
          </TouchableOpacity>
        </View>
        <Text style={styles.favoriteCategory}>{item.category}</Text>
        <View style={styles.favoriteMeta}>
          <View style={styles.ratingContainer}>
            <Star size={14} color="#F59E0B" fill="#F59E0B" />
            <Text style={styles.ratingText}>{item.rating}</Text>
            <Text style={styles.reviewsText}>({item.reviews})</Text>
          </View>
          <View style={styles.locationContainer}>
            <MapPin size={12} color="#6B7280" />
            <Text style={styles.distanceText}>{item.distance}</Text>
          </View>
        </View>
        <View style={styles.favoriteFooter}>
          <Text style={styles.priceText}>{item.price}</Text>
          <Text style={styles.lastContactedText}>Último contacto: {item.lastContacted}</Text>
        </View>
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.contactButton}>
            <Text style={styles.contactButtonText}>Contactar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.removeButton}>
            <Text style={styles.removeButtonText}>Eliminar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Favoritos</Text>
        <Text style={styles.subtitle}>Tus proveedores de confianza</Text>
      </View>

      {favoriteProviders.length === 0 ? (
        <View style={styles.emptyState}>
          <Heart size={64} color="#D1D5DB" />
          <Text style={styles.emptyTitle}>Sin favoritos aún</Text>
          <Text style={styles.emptyText}>
            Guarda tus proveedores favoritos para acceder fácilmente a ellos
          </Text>
        </View>
      ) : (
        <FlatList
          data={favoriteProviders}
          renderItem={renderFavoriteCard}
          keyExtractor={(item) => item.id.toString()}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.favoritesList}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  favoritesList: {
    padding: 20,
  },
  favoriteCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    overflow: 'hidden',
  },
  favoriteImage: {
    width: '100%',
    height: 120,
  },
  favoriteContent: {
    padding: 16,
  },
  favoriteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  favoriteName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    flex: 1,
  },
  heartButton: {
    padding: 4,
  },
  favoriteCategory: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
  },
  favoriteMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
  },
  reviewsText: {
    fontSize: 12,
    color: '#6B7280',
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  distanceText: {
    fontSize: 12,
    color: '#6B7280',
  },
  favoriteFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  priceText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#3B82F6',
  },
  lastContactedText: {
    fontSize: 12,
    color: '#6B7280',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  contactButton: {
    flex: 1,
    backgroundColor: '#3B82F6',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  contactButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  removeButton: {
    flex: 1,
    backgroundColor: '#F3F4F6',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  removeButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
  },
});
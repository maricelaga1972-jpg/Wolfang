import React, { createContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  userType: 'user' | 'provider';
  avatar?: string;
  businessName?: string;
  category?: string;
  location?: string;
  phone?: string;
  verified?: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: Partial<User>, password: string) => Promise<void>;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  register: async () => {},
  logout: () => {},
});

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading user data from storage
    const loadUserData = async () => {
      try {
        // Here you would typically load from AsyncStorage or similar
        // For demo purposes, we'll set a default user
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Simulate logged in user
        const demoUser: User = {
          id: '1',
          name: 'Juan Pérez',
          email: 'juan@example.com',
          userType: 'user',
          avatar: 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=150',
          location: 'Ciudad de México',
        };
        
        setUser(demoUser);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Error loading user data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadUserData();
  }, []);

  const login = async (email: string, password: string): Promise<void> => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock user data based on email
      const isProvider = email.includes('provider') || email.includes('business');
      const userData: User = {
        id: Math.random().toString(),
        name: isProvider ? 'TechFix Pro' : 'María González',
        email,
        userType: isProvider ? 'provider' : 'user',
        avatar: 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=150',
        businessName: isProvider ? 'TechFix Pro Services' : undefined,
        category: isProvider ? 'Tecnología' : undefined,
        location: 'Ciudad de México',
        verified: isProvider,
      };

      setUser(userData);
      setIsAuthenticated(true);
    } catch (error) {
      throw new Error('Error de autenticación');
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: Partial<User>, password: string): Promise<void> => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const newUser: User = {
        id: Math.random().toString(),
        name: userData.name || 'Usuario',
        email: userData.email || '',
        userType: userData.userType || 'user',
        businessName: userData.businessName,
        category: userData.category,
        location: userData.location,
        phone: userData.phone,
        verified: userData.userType === 'provider' ? false : true,
      };

      setUser(newUser);
      setIsAuthenticated(true);
    } catch (error) {
      throw new Error('Error en el registro');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = (): void => {
    setUser(null);
    setIsAuthenticated(false);
  };

  const value: AuthContextType = {
    user,
    isAuthenticated,
    isLoading,
    login,
    register,
    logout,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}